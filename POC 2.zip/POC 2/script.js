var escoteiros = [{
    nome : "Lucia",
    idade : 12
},{
    nome : "Alan",
    idade : 15
},{
    nome : "Bruno",
    idade : 22
},{
    nome : "Yvi",
    idade : 19
}]

function generateRow(es){
    return `<ol><li>${es.nome}</li><li>${es.idade}</li></ol>`
}

window.onload = function(){
    let nomeLista = document.getElementById("nomelista")
    for(var i=0; i<escoteiros.length;i++){
        nomeLista.innerHTML += `<article><h1>${escoteiros[i].nome}</h1><h2>${escoteiros[i].idade}</h2></article>`
    }

    // MAP

    var mapList = document.getElementById("listaMAP")
    var newEscoteiros = escoteiros.map (generateRow)
    for (var i=0; i<newEscoteiros.length;i++){
        mapList.innerHTML+=newEscoteiros[i]
    }
// FILTER

var escoteirosFiltered = escoteiros.filter(filterEscot)
var escoteirosFilteredMap = escoteirosFiltered.map(generateRow)
function filterEscot(es){
    return es.idade >= 18

}

var filterList = document.getElementById("listaFILTER")
for (var i=0;escoteirosFilteredMap.length;i++){
    filterList.innerHTML += escoteirosFilteredMap[i]
}

// SORT

function compareIdade(a,b){ return a.idade - b.idade}
var escoteirosCopy = escoteiros.slice()
escoteirosCopy.sort(compareIdade)
var escoteirosSortMap = escoteirosCopy.map(generateRow)
var sortList = document.getElementById("listSORT")
for (var i=0; i<escoteirosSortMap.length; i++){
    sortList.innerHTML += escoteirosSortMap[i]
}

// REDUCE



    



    // SPREAD


}
